package com.razor.mall.guangguang.core.dal.userinfo;

import com.razor.mall.guangguang.core.dal.model.UserInfoDO;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserInfoRepository extends JpaRepository<UserInfoDO, Long> {
}
