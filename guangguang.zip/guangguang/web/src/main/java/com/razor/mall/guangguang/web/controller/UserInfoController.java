package com.razor.mall.guangguang.web.controller;

import java.util.List;

import com.razor.mall.guangguang.core.dal.userinfo.UserInfoRepository;
import com.razor.mall.guangguang.core.dal.model.UserInfoDO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhouqun
 */
@RestController
@RequestMapping("/userInfo")
public class UserInfoController {
    @Autowired
    private UserInfoRepository userRepository;

    //    http://127.0.0.1:8080/userInfo/getUserByUserId?userId=123


    @RequestMapping("/getUserByUserId")
    public String getUserByUserId(@RequestParam("userId") Long userId) {
        List<UserInfoDO> users = userRepository.findAll();
        return users.toString();
    }
}
