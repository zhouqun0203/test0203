package com.razor.mall.guangguang.core.dal.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

/**
 * 用户实体类
 *
 * @author zhouqun
 */
@Entity
@Table(name = "USER_INFO")
@Data
public class UserInfoDO {
    @Id
    private Long id;

    private Date gmtCreate;

    private Date gmtModified;

    private String openId;

    private String nickName;

    private String loginId;

    private String userPwd;

    private Integer level;

    private String gender;

    private String imgUrl;

    private String description;

    private String attributes;
}